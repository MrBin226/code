clc;
clear;
close all;
for i=1:3
    A();
end